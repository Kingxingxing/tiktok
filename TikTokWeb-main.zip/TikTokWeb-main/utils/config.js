module.exports = {
    'ipAddress': 'http://localhost:3039'
};