# TikTokWeb

<img src="https://tvax2.sinaimg.cn/large/006908GAly1h1e6e0mjmbj30m217a168.jpg" alt="image" style="zoom:75%;" />

# Install

```
git clone https://github.com/Johnserf-Seed/TikTokWeb.git
cd TikTokWeb
npm i
```

# Run

```
npm start
http://localhost:3000/
```

<img src="https://visitor-badge.glitch.me/badge?page_id=johnserf-seed.tiktokweb" alt="访客统计" />
